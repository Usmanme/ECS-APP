<?php $__env->startSection('content'); ?>
    <!-- Left Sidebar -->
    <?php echo $__env->make('layouts.partials.left-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ./Left Sidebar -->

    <!-- Customer -->
    <div class="col-lg-9 p-0" id="booking_right_part">
        <div class="booking_header_part">
            <div class="booking_header_title" id="Title">
                <h2>Customer</h2>
                <div class="center-heading">
                    <h6 class="color01">Home >></h6>
                    <h6 class="color02">Dashboard</h6>
                </div>
            </div>
            <div class="profile">
                <img src="./assets/images/notification.png" class="notification-icon">
                <img src="./assets/images/admin.png" class="admin-pic">
                <p class="admin-name">king Albert</p>
            </div>
        </div>

        <!-- Save -->
        <?php if(session('status_save') === 'true'): ?>
            <div class="ecs_alert alert alert-success" role="alert">
                Customer has been registered successfully.
            </div>
        <?php elseif(session('status_save') === 'false'): ?>
            <div class="ecs_alert alert alert-danger" role="alert">
                <b>Error:</b> Your customer could not be register.
            </div>
        <?php endif; ?>

        <!-- Edit -->
        <?php if(session('status_edit') === 'true'): ?>
            <div class="ecs_alert alert alert-success" role="alert">
                Customer has been updated successfully.
            </div>
        <?php elseif(session('status_edit') === 'false'): ?>
            <div class="ecs_alert alert alert-danger" role="alert">
                <b>Error:</b> Your customer could not be update.
            </div>
        <?php endif; ?>

        <table id="bookingtable_in_booking" class="display" style="width:100%">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Mobile Number</th>
                    <th>Email</th>
                    <th>Nationality</th>
                    <th>Company</th>
                    <th>Department if B2B</th>
                    <th>Designation If B2B</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if(!empty($data)): ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($value->id); ?></td>
                            <td>
                                <div class="nameentry">
                                    <img src="<?php echo e($value->img != '' ? asset('/uploads/' . $value->img) : asset('/assets/images/avarat.png')); ?>"
                                        class="customerpic">
                                </div>
                            </td>
                            <td><?php echo e($value->name); ?></td>
                            <td><?php echo e($value->mobile_number); ?></td>
                            <td><?php echo e($value->email); ?></td>
                            <td><?php echo e($value->nationality); ?></td>
                            <td><?php echo e($value->company); ?></td>
                            <td><?php echo e($value->department ?? '--'); ?></td>
                            <td><?php echo e($value->designation ?? '--'); ?></td>
                            <td>
                                <a href="javascript:void(0)" class="edit_customer_btn" data-target="#editCustomerModal"
                                    data-toggle="modal" data-edit_action="<?php echo e(url('/customers/update/' . $value->id)); ?>">
                                    <img src="<?php echo e(url('/assets/images/edit-icon.png')); ?>">
                                </a>
                            </td>
                            <input type="hidden" data-name="<?php echo e($value->name); ?>" data-mobile_number="<?php echo e($value->mobile_number); ?>" data-email="<?php echo e($value->email); ?>" data-nationality="<?php echo e($value->nationality); ?>" data-company="<?php echo e($value->company); ?>" data-department="<?php echo e($value->department); ?>" data-designation="<?php echo e($value->designation); ?>" data-img="<?php echo e($value->img != '' ? asset('/uploads/' . $value->img) : asset('/assets/images/avarat.png')); ?>">
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
            <tfoot>
                <tr>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Mobile Number</th>
                    <th>Email</th>
                    <th>Nationality</th>
                    <th>Company</th>
                    <th>Department if B2B</th>
                    <th>Designation If B2B</th>
                    <th>Action</th>
                </tr>
            </tfoot>
        </table>
    </div>
    <!-- ./Customer -->

    <!-- Add Modal -->
    <div class="modal fade modal_form" id="addCustomerModal" tabindex="-1" role="dialog"
        aria-labelledby="addCustomerModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addCustomerModalLabel">Add New Customer</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(url('/customers/store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" class="form-control" name="name" id="name"
                                placeholder="Enter Customer Name" required>
                        </div>
                        <div class="form-group">
                            <label for="mobile_number">Mobile Number</label>
                            <input type="text" class="form-control" name="mobile_number" id="mobile_number"
                                placeholder="Enter Mobile Number" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="text" class="form-control" name="email" id="email"
                                placeholder="Enter Email" required>
                        </div>
                        <div class="form-group">
                            <label for="nationality">Nationality</label>
                            <input type="text" class="form-control" name="nationality" id="nationality"
                                placeholder="Enter Nationality">
                        </div>
                        <div class="form-group">
                            <label for="company">Company</label>
                            <input type="text" class="form-control" name="company" id="company"
                                placeholder="Enter Company" required>
                        </div>
                        <div class="form-group">
                            <label for="department">Department if B2B</label>
                            <input type="text" class="form-control" name="department" id="department"
                                placeholder="Enter Department if B2B" >
                        </div>
                        <div class="form-group">
                            <label for="designation">Designation If B2B</label>
                            <input type="text" class="form-control" name="designation" id="designation"
                                placeholder="Enter Designation If B2B" >
                        </div>
                        <div class="form-group">
                            <label for="customer_img">Image</label>
                            <input type="file" class="form-control" name="customer_img" id="customer_img"
                                accept="image/png, image/gif, image/jpeg" required>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-black">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- ./ Add Modal -->

    <!-- Edit Modal -->
    <div class="modal fade modal_form" id="editCustomerModal" tabindex="-1" role="dialog"
        aria-labelledby="editCustomerModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editCustomerModalLabel">Edit Customer</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="#" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" class="form-control" name="name" id="name"
                                placeholder="Enter Customer Name" required>
                        </div>
                        <div class="form-group">
                            <label for="mobile_number">Mobile Number</label>
                            <input type="text" class="form-control" name="mobile_number" id="mobile_number"
                                placeholder="Enter Mobile Number" required>
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="text" class="form-control" name="email" id="email"
                                placeholder="Enter Email" required>
                        </div>
                        <div class="form-group">
                            <label for="nationality">Nationality</label>
                            <input type="text" class="form-control" name="nationality" id="nationality"
                                placeholder="Enter Nationality">
                        </div>
                        <div class="form-group">
                            <label for="company">Company</label>
                            <input type="text" class="form-control" name="company" id="company"
                                placeholder="Enter Company" required>
                        </div>
                        <div class="form-group">
                            <label for="department">Department if B2B</label>
                            <input type="text" class="form-control" name="department" id="department"
                                placeholder="Enter Department if B2B" required>
                        </div>
                        <div class="form-group">
                            <label for="designation">Designation If B2B</label>
                            <input type="text" class="form-control" name="designation" id="designation"
                                placeholder="Enter Designation If B2B" required>
                        </div>
                        <div class="form-group">
                            <label for="customer_img">Image</label>
                            <input type="file" class="form-control" name="customer_img" id="customer_img"
                                accept="image/png, image/gif, image/jpeg">
                            <img src="" class="edit_modal_img">
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-black">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- ./ Edit Modal -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u831209024/domains/markition.com/public_html/ecsbackend/resources/views/pages/customer.blade.php ENDPATH**/ ?>