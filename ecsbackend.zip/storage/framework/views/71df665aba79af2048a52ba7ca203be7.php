<?php $__env->startSection('content'); ?>
    <form method="post" action="<?php echo e(route('login.perform')); ?>" class="login-form">

        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />

        <h1 class="h3 mb-3 fw-normal">Login</h1>

        <p>Enter your email and password to Login</p>

        <?php echo $__env->make('layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="form-group mb-3">
            <label class="floatingName login_form_label">Email</label>
            <input type="text" class="form-control" name="username" value="<?php echo e(old('username')); ?>" placeholder="Username"
                required="required" autofocus>
            <?php if($errors->has('username')): ?>
                <span class="text-danger text-left"><?php echo e($errors->first('username')); ?></span>
            <?php endif; ?>
        </div>

        <div class="form-group mb-3">
            <label class="floatingPassword login_form_label">Password</label>
            <input type="password" class="form-control" name="password" value="<?php echo e(old('password')); ?>" placeholder="Password"
                required="required">
            <?php if($errors->has('password')): ?>
                <span class="text-danger text-left"><?php echo e($errors->first('password')); ?></span>
            <?php endif; ?>
        </div>

        <button class="w-100 btn btn-lg btn-primary login_btn" type="submit">Login</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u831209024/domains/markition.com/public_html/ecsbackend/resources/views/auth/login.blade.php ENDPATH**/ ?>