<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!--<title>ECS Email Template</title>-->
    <link href="<?php echo e(asset('assets/email_images/style.css')); ?>" rel="stylesheet" />
</head>

<body>
    <div class="mainBox">
        <div class="header">
            <!--<div class="top">-->
            <!--    <img src="<?php echo e(asset('assets/email_images/Logo.png')); ?>" alt="logo" />-->
            <!--</div>-->
            <!--<div class="middle">-->
            <!--    <img src="<?php echo e(asset('assets/email_images/banner.jpg')); ?>" alt="banner" />-->
            <!--</div>-->
        </div>
        <div class="body">
            <p class="message">Congratulations! Your ride has been Confirmed.</p>
            <div class="innerBox">
                <h2 class="heading">Your Trip Details:</h2>
                <p>Paid Amount : <?php echo e($totalAmount); ?></p>
                <p>Fare: <?php echo e($amount); ?></p>
                <p>VAT % : <?php echo e($vat); ?>%</p>
                <p>Pickup Location : <?php echo e($location_from); ?></p>
                <p>Drop Off Location : <?php echo e($location_to); ?></p>
                <p>Vehicle Category : <?php echo e($trip_cat); ?></p>
                <p>Vehicle Type :<?php echo e($trip_type); ?></p>
                <p>Trip Date : <?php echo e($trip_date); ?></p>
                <p>Trip Time : <?php echo e($trip_time); ?></p>
            </div>
            <p class="message2">
                Executive Chauffeur Service KSA has been providing premium journeys to
                its clients for over a decade. Through strategic partnerships, we
                offer luxury transportation services in all major cities around the
                KSA. From a Mercedes Benz sedan to a luxury SUV, we have the right
                vehicle to make your journey exceptional.
            </p>
        </div>
        <div class="footer">
            <p class="text">© 2024 ECS Provider. All Rights Reserved.</p>
        </div>
    </div>
</body>

</html>
<?php /**PATH /home/u831209024/domains/markition.com/public_html/ecsbackend/resources/views/emails/welcome.blade.php ENDPATH**/ ?>