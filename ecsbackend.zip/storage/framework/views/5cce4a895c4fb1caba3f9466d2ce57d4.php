<div id="left-side-bar" class="col-lg-3">
    <div>
        <div class="logo-container">
            
        </div>
        <div class="extra"></div>
    </div>
    <div class="buttons">
        <a href="<?php echo e(url('/')); ?>" class="button" id="dashboard"><img src="<?php echo e(asset('/assets/images/Home.png')); ?>" class="icon-logo">
            <p>Dashboard</p>
        </a>
        <!-- <a href="<?php echo e(url('booking')); ?>" class="button" id="booking"><img src="<?php echo e(asset('/assets/images/Booking.png')); ?>" class="icon-logo">
            <p>Bookings</p>
        </a> -->
        <a href="<?php echo e(url('drivers')); ?>" class="button" id="drivers"><img src="<?php echo e(asset('/assets/images/Drivers.png')); ?>" class="icon-logo">
            <p>Drivers</p>
        </a>
        <a href="<?php echo e(url('vehicles')); ?>" class="button" id="vehicles"><img src="<?php echo e(asset('/assets/images/Vehicles.png')); ?>" class="icon-logo">
            <p>Vehicles</p>
        </a>
        <a href="<?php echo e(url('rides')); ?>" class="button" id="vehicles"><img src="<?php echo e(asset('/assets/images/ride-icon.png')); ?>" class="icon-logo">
            <p>Booking</p>
        </a>
        <a href="<?php echo e(url('customers')); ?>" class="button" id="vehicles"><img src="<?php echo e(asset('/assets/images/client-icon.png')); ?>" class="icon-logo">
            <p>Customers</p>
        </a>
         <a href="<?php echo e(url('finance')); ?>" class="button" id="vehicles"><img src="<?php echo e(asset('/assets/images/bookingrs.png')); ?>" class="icon-logo">
            <p>Finance</p>
        </a>
    </div>
    <a href="<?php echo e(url('/logout')); ?>" class="btn btn-danger logout">Logout</a>
</div>
<?php /**PATH /home/u831209024/domains/markition.com/public_html/ecsbackend/resources/views/layouts/partials/left-sidebar.blade.php ENDPATH**/ ?>