<?php $__env->startSection('content'); ?>
    <!-- Left Sidebar -->
    <?php echo $__env->make('layouts.partials.left-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- ./Left Sidebar -->

    <!-- Vehicle -->
    <div class="col-lg-9 p-0" id="booking_right_part">
        <div class="booking_header_part">
            <div class="booking_header_title" id="Title">
                <h2>Drivers</h2>
                <div class="center-heading">
                    <h6 class="color01">Home >></h6>
                    <h6 class="color02">Driver Listing</h6>
                </div>
            </div>
            <div class="profile">
                <img src="./assets/images/notification.png" class="notification-icon">
                <img src="./assets/images/admin.png" class="admin-pic">
                <p class="admin-name">king Albert</p>
            </div>
        </div>

        <!-- Save -->
        <?php if(session('status_save') === 'true'): ?>
            <div class="ecs_alert alert alert-success" role="alert">
                Driver has been registered successfully.
            </div>
        <?php elseif(session('status_save') === 'false'): ?>
            <div class="ecs_alert alert alert-danger" role="alert">
                <b>Error:</b> Your driver could not be register.
            </div>
        <?php endif; ?>

        <!-- Edit -->
        <?php if(session('status_edit') === 'true'): ?>
            <div class="ecs_alert alert alert-success" role="alert">
                Driver has been updated successfully.
            </div>
        <?php elseif(session('status_edit') === 'false'): ?>
            <div class="ecs_alert alert alert-danger" role="alert">
                <b>Error:</b> Your driver could not be update.
            </div>
        <?php endif; ?>

        <table id="bookingtable_in_booking" class="display" style="width:100%">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Driver</th>
                    <th>Email Address</th>
                    <th>Number</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if(!empty($data)): ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($value->phone_number); ?></td>
                            <td>
                                <div class="nameentry">
                                    <img src="<?php echo e($value->img != '' ? asset('/uploads/' . $value->img) : asset('/assets/images/avarat.png')); ?>"
                                        class="customerpic">
                                    <p><?php echo e($value->firstname . ' ' . $value->lastname); ?></p>
                                </div>
                            </td>
                            <td><?php echo e($value->email_addr); ?></td>
                            <td><?php echo e($value->phone_number); ?></td>
                            <td>
                                <div class="booking_status">Available</div>
                            </td>
                            <td>
                                <a href="javascript:void(0)" class="edit_driver_btn" data-target="#editDriverModal"
                                    data-toggle="modal" data-edit_action="<?php echo e(url('/drivers/update/' . $value->id)); ?>">
                                    <img src="<?php echo e(url('/assets/images/edit-icon.png')); ?>">
                                </a>
                            </td>
                            <input type="hidden" data-firstname="<?php echo e($value->firstname); ?>"
                                data-lastname="<?php echo e($value->lastname); ?>" data-phone_number="<?php echo e($value->phone_number); ?>"
                                data-iqama_number="<?php echo e($value->iqama_number); ?>" data-email_addr="<?php echo e($value->email_addr); ?>"
                                data-img="<?php echo e($value->img != '' ? asset('/uploads/' . $value->img) : asset('/assets/images/avarat.png')); ?>">
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </tbody>
            <tfoot>
                <tr>
                    <th>Driver</th>
                    <th>Email Address</th>
                    <th>Number</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </tfoot>
        </table>
    </div>
    <!-- ./Vehicle -->

    <!-- Add Modal -->
    <div class="modal fade modal_form" id="addDriverModal" tabindex="-1" role="dialog"
        aria-labelledby="addDriverModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addDriverModalLabel">Add New Driver</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(url('/drivers/store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="firstname">First Name</label>
                            <input type="text" class="form-control" name="firstname" id="firstname"
                                placeholder="Enter First Name" required>
                        </div>
                        <div class="form-group">
                            <label for="lastname">Last Name</label>
                            <input type="text" class="form-control" name="lastname" id="lastname"
                                placeholder="Enter Last Name" required>
                        </div>
                        <div class="form-group">
                            <label for="phone_number">Number</label>
                            <input type="text" class="form-control" name="phone_number" id="phone_number"
                                placeholder="Enter Phone Number" required>
                        </div>
                        <div class="form-group">
                            <label for="iqama_number">Iqama Number</label>
                            <input type="text" class="form-control" name="iqama_number" id="iqama_number"
                                placeholder="Enter Iqama Number" required>
                        </div>
                        <div class="form-group">
                            <label for="email_addr">Email Address</label>
                            <input type="text" class="form-control" name="email_addr" id="email_addr"
                                placeholder="Enter Email Address" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="vehicles">Vehicle</label>
                            <select class="form-control" name="vehicles" id="vehicles" required>
                                <?php if(!empty($vehicle_data)): ?>
                                    <option value="" selected disabled>Choose vehicle</option>
                                    <!--<?php $__currentLoopData = $vehicle_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>-->
                                    <!--    <option value="<?php echo e($value->id); ?>">-->
                                    <!--        <?php echo e($value->code . ' ' . $value->type . '(' . $value->color . ')'); ?></option>-->
                                    <!--<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
                                    <?php $__currentLoopData = $vehicle_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value->id); ?>">
                                            <?php echo e($value->reg_no); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="driver_img">Image</label>
                            <input type="file" class="form-control" name="driver_img" id="driver_img"
                                accept="image/png, image/gif, image/jpeg" required>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-black">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- ./ Add Modal -->

    <!-- Edit Modal -->
    <div class="modal fade modal_form" id="editDriverModal" tabindex="-1" role="dialog"
        aria-labelledby="editDriverModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editDriverModalLabel">Edit Driver</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="#" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="firstname">First Name</label>
                            <input type="text" class="form-control" name="firstname" id="firstname"
                                placeholder="Enter First Name" required>
                        </div>
                        <div class="form-group">
                            <label for="lastname">Last Name</label>
                            <input type="text" class="form-control" name="lastname" id="lastname"
                                placeholder="Enter Last Name" required>
                        </div>
                        <div class="form-group">
                            <label for="phone_number">Number</label>
                            <input type="text" class="form-control" name="phone_number" id="phone_number"
                                placeholder="Enter Phone Number" required>
                        </div>
                        <div class="form-group">
                            <label for="iqama_number">Iqama Number</label>
                            <input type="text" class="form-control" name="iqama_number" id="iqama_number"
                                placeholder="Enter Iqama Number" required>
                        </div>
                        <div class="form-group">
                            <label for="email_addr">Email Address</label>
                            <input type="text" class="form-control" name="email_addr" id="email_addr"
                                placeholder="Enter Email Address" required>
                        </div>
                         <div class="form-group">
                            <label for="driver_img">Vehicle</label>
                            <select name="vehicle_id" class="form-control" id="vehicle_id">
                                <?php $__empty_1 = true; $__currentLoopData = $vehicle_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($vehicle->id); ?>"><?php echo e($vehicle->reg_no); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option value="">--No Vehicle Found--</option>
                                <?php endif; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="driver_img">Image</label>
                            <input type="file" class="form-control" name="driver_img" id="driver_img"
                                accept="image/png, image/gif, image/jpeg">
                            <img src="" class="edit_modal_img">
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-black">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- ./ Edit Modal -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u831209024/domains/markition.com/public_html/ecsbackend/resources/views/pages/driver.blade.php ENDPATH**/ ?>